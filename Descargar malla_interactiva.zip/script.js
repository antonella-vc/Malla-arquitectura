document.querySelectorAll(".materia input[type='checkbox']").forEach((checkbox) => {
  checkbox.addEventListener("change", () => {
    if (!checkbox.checked) return;

    document.querySelectorAll(".materia.bloqueada").forEach((materia) => {
      const requisitos = materia.dataset.requiere?.split(",") || [];
      const cumplidos = requisitos.every((req) => {
        const input = document.querySelector(
          `.materia[data-id='${req}'] input[type='checkbox']`
        );
        return input?.checked;
      });

      if (cumplidos) {
        materia.classList.remove("bloqueada");
        materia.querySelector("input").disabled = false;
      }
    });
  });
});
